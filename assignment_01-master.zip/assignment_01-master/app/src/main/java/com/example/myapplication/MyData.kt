package com.example.myapplication

class MyData : ArrayList<MyDataItem>()